# RESTfulWebservice-SlimFramework

Membuat WebService dengan Slim Framework. Pada tutorial kita akan belajar menggunakan slim framework 3.0 untuk membuat RESTful webservice. RESTful adalah arsitektur REST(Representational State Transfer) berbasis webservice. 
