<?php
	$host = "localhost";
	$user = "root";
	$password = "usbw";
	$database = "ims";
	$connect = mysql_connect($host, $user, $password);
	mysql_select_db($database,$connect);
?>